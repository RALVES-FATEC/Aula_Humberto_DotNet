﻿Module Module1
    'Declaração de Variáveis Públicas
    Public diretorio As String
    Public db As New ADODB.Connection 'Variável do Banco
    Public rs As New ADODB.Recordset 'Variável das Tabelas 
    Public sql, aux_cpf, resp As String 'Query de Leitura e Escrita
    Public cont As Integer

    Sub Carregar_tipo()
        Try
            With Form1.cmb_campo.Items
                .Add("CPF")
                .Add("NOME")
            End With
            Form1.cmb_campo.SelectedIndex = 1
        Catch ex As Exception
            MsgBox("Erro ao Carregar os dados", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Sub Carregar_dados()
        'Carregar Registros do banco no datagridview
        Try
            sql = $"select * from tb_cadastro order by nome asc"
            rs = db.Execute(sql)
            With Form1.dgv_dados
                cont = 0
                .Rows.Clear()
                Do While rs.EOF = False 'Faça enquanto existir registros
                    cont = cont + 1
                    .Rows.Add(cont, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, Nothing, Nothing)
                    rs.MoveNext() 'Mover para próximo registro
                Loop

            End With
        Catch ex As Exception
            MsgBox("Erro ao Carregar os dados", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub


    Sub Conecta_banco()
        'String de Conexão SQL-SERVER
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=SQLOLEDB;Data Source=LAB5-14;Initial Catalog=cad_clientes_3dsm_26;trusted_connection=yes;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Sub Limpar_cadastro()
        Try
            With Form1
                .txt_cpf.Clear()
                .txt_nome.Clear()
                .cmb_data_nasc.Value = Now
                .txt_fone.Clear()
                .txt_email.Clear()
                .img_foto.Load(Application.StartupPath & "\fotos\nova_foto.png")
                .txt_cpf.Focus()
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub




End Module

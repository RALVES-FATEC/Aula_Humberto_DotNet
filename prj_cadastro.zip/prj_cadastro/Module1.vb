﻿Module Module1
    'Declaração de Variáveis Públicas
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public diretorio, SQL, resp As String

    Sub Conectar_banco()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=SQLOLEDB;Data Source=LAB5-14;Initial Catalog=cad_clientes_3dsm_26;trusted_connection=yes;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Sub limpar_cadastro()
        With Form1
            .txt_cpf.Clear()
            .txt_nome.Clear()
            .cmb_data_nasc.Value = Now
            .cmb_profissao.Text = ""
            .txt_celular.Clear()
            .img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
            .txt_cpf.Focus()
        End With
    End Sub


End Module

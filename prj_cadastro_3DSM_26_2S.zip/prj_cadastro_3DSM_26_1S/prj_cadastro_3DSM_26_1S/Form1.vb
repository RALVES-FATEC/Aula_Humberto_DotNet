﻿Public Class Form1
    Private Sub Img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\Fotos"
                .ShowDialog()
                diretorio = .FileName
                img_foto.Load(diretorio)
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Conecta_banco()
        Carregar_dados()
        Carregar_tipo()
    End Sub

    Private Sub Btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        Try
            sql = $"select * from tb_cadastro where cpf='{txt_cpf.Text}'"
            rs = db.Execute(sql)
            If rs.EOF = True Then
                sql = $"insert into tb_cadastro (cpf,nome,data_nasc,celular,email,foto)
                      values ('{txt_cpf.Text}','{txt_nome.Text}',
                              '{cmb_data_nasc.Value.ToShortDateString}',
                              '{txt_fone.Text}','{txt_email.Text}',
                              '{diretorio}')"
                rs = db.Execute(UCase(sql))
                MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

            Else
                sql = $"update tb_cadastro set nome='{txt_nome.Text}', 
                                             data_nasc='{cmb_data_nasc.Value.ToShortDateString}',
                                             celular='{txt_fone.Text}',
                                             email='{txt_email.Text}',
                                             foto='{diretorio}'
                                             where cpf='{txt_cpf.Text}'"
                rs = db.Execute(UCase(sql))
                MsgBox("Dados editados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

            End If
            Limpar_cadastro()
            Carregar_dados()

        Catch ex As Exception
            MsgBox("Erro ao Gravar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub txt_cpf_DoubleClick(sender As Object, e As EventArgs) Handles txt_cpf.DoubleClick
        Limpar_cadastro()
    End Sub

    Private Sub txt_buscar_TextChanged(sender As Object, e As EventArgs) Handles txt_buscar.TextChanged
        Try
            sql = $"select * from tb_cadastro where 
                  {cmb_campo.Text} like '{txt_buscar.Text}%'"
            rs = db.Execute(sql)
            With dgv_dados
                cont = 0
                .Rows.Clear()
                Do While rs.EOF = False 'Faça enquanto existir registros
                    cont = cont + 1
                    .Rows.Add(cont, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(5).Value, rs.Fields(4).Value, Nothing, Nothing)
                    rs.MoveNext() 'Mover para próximo registro
                Loop

            End With
        Catch ex As Exception
            MsgBox("Erro ao Carregar os dados", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub Dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Try
            With dgv_dados
                If .CurrentRow.Cells(6).Selected = True Then
                    aux_cpf = .CurrentRow.Cells(1).Value
                    sql = $"select * from tb_cadastro where cpf='{aux_cpf}'"
                    rs = db.Execute(sql)
                    txt_cpf.Text = rs.Fields(1).Value
                    txt_nome.Text = rs.Fields(2).Value
                    cmb_data_nasc.Value = rs.Fields(3).Value
                    txt_fone.Text = rs.Fields(5).Value
                    txt_email.Text = rs.Fields(4).Value
                    img_foto.Load(rs.Fields(6).Value)
                ElseIf .CurrentRow.Cells(7).Selected = True Then
                    aux_cpf = .CurrentRow.Cells(1).Value
                    resp = MsgBox("Deseja excluir o cpf: " & aux_cpf & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = MsgBoxResult.Yes Then
                        sql = $"delete from tb_cadastro where cpf='{aux_cpf}'"
                        rs = db.Execute(sql)
                        Carregar_dados()
                        Limpar_cadastro()
                    End If
                Else
                    Exit Sub
                End If
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub


End Class

﻿Public Class Form1
    Private Sub Btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        'Try
        SQL = $"select * from tb_clientes where cpf='{txt_cpf.Text}'"
            rs = db.Execute(SQL)
            If rs.EOF = True Then 'Se não existir o CPF na tabela
            SQL = $"insert into tb_clientes (cpf,nome,data_nasc,profissao,celular,foto) values
                    '{txt_cpf.Text}','{txt_nome.Text}',
                    '{cmb_data_nasc.Value.ToShortDateString}',
                    '{cmb_profissao.Text}',
                    '{txt_celular.Text}','{diretorio}'"
            rs = db.Execute(UCase(SQL))
                MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                limpar_cadastro()
            Else
                MsgBox("CPF já cadastrado!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")

            End If
        'Catch ex As Exception
        'MsgBox("Erro ao Gravar", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")

        '        End Try
    End Sub

    Private Sub Img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "SELECIONE UMA FOTO DO CLIENTE" 'Título do popup
                .InitialDirectory = Application.StartupPath & "\fotos" 'Diretório das fotos
                .ShowDialog() 'Exibir Popup
                diretorio = .FileName 'Variável recebe diretório de fotos
                img_foto.Load(diretorio) 'Upload da foto

            End With

        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Conectar_banco()
    End Sub
End Class
